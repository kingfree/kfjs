This is the README file for SHJS - Syntax Highlighting in JavaScript.

This distribution contains the following files:

sh_main.js
  The main script.
sh_main.min.js
  The main script, compressed by YUI Compressor
  (http://www.julienlecomte.net/yuicompressor/).
sh_style.css
  Default style sheet.
css/*.css
  Style sheets for different highlighting themes.
css/*.min.css
  Compressed versions of the above.
lang/*.js
  Scripts for different programming languages.
lang/*.min.js
  Compressed versions of the above.
doc/
  Documentation.

See index.html for instructions.

See gpl.txt for licensing terms.
